package mca1program.example.drawingapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class ShapeDrawingView extends View {
    private Paint paint;
    private String currentShape = "Circle";
    private String currentColor = "#FF0000";
    private String displayText = "";
    private List<Shape> shapes = new ArrayList<>();
    public ShapeDrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();
        paint.setTextSize(50);
    }
    public void setShape(String shape) {
        currentShape = shape;
    }
    public void setColor(String color) {
        currentColor = color;
    }
    public void setDisplayText(String text) {
        displayText = text;
    }
    public void clearCanvas() {
        shapes.clear();
        invalidate();
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Shape shape : shapes) {
            paint.setColor(Color.parseColor(shape.color));
            if (shape.type.equals("Circle")) {
                canvas.drawCircle(shape.x, shape.y, 50, paint);
            } else if (shape.type.equals("Rectangle")) {
                canvas.drawRect(shape.x - 50, shape.y - 50, shape.x + 50, shape.y + 50, paint);
            }
        }
        if (!displayText.isEmpty()) {
            paint.setColor(Color.BLACK);
            canvas.drawText(displayText, 50, 100, paint);
        }
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            float x = event.getX();
            float y = event.getY();
            shapes.add(new Shape(currentShape, currentColor, x, y));
            invalidate();
        }
        return true;
    }
    private static class Shape {
        String type;
        String color;
        float x, y;
        Shape(String type, String color, float x, float y) {
            this.type = type;
            this.color = color;
            this.x = x;
            this.y = y;
        }
    }
}