package mca1program.example.drawingapp;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
        public class MainActivity extends AppCompatActivity {
            private ShapeDrawingView drawingView;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);
                drawingView = findViewById(R.id.drawingView);
                RadioGroup shapeSelector = findViewById(R.id.shapeSelector);
                Spinner colorSelector = findViewById(R.id.colorSelector);
                EditText textInput = findViewById(R.id.textInput);
                Button btnClear = findViewById(R.id.btnClear);
// Populate the color selector spinner
                String[] colors = {"Red", "Blue", "Green", "Yellow"};
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_item, colors);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                colorSelector.setAdapter(adapter);
// Handle shape selection
                shapeSelector.setOnCheckedChangeListener((group, checkedId) -> {
                    if (checkedId == R.id.rbCircle) {
                        drawingView.setShape("Circle");
                    } else if (checkedId == R.id.rbRectangle) {
                        drawingView.setShape("Rectangle");
                    }
                });
// Handle color selection
                colorSelector.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(android.widget.AdapterView<?> parent, View view, int
                            position, long id) {
                        String selectedColor = colors[position];
                        String colorCode = "#FF0000"; // Default to Red
                        switch (selectedColor) {
                            case "Red":
                                colorCode = "#FF0000";
                                break;
                            case "Blue":
                                colorCode = "#0000FF";
                                break;
                            case "Green":
                                colorCode = "#00FF00";
                                break;
                            case "Yellow":
                                colorCode = "#FFFF00";
                                break;
                        }
                        drawingView.setColor(colorCode);
                    }

                    @Override
                    public void onNothingSelected(android.widget.AdapterView<?> parent) {
                    }
                });

// Handle text input
                textInput.setOnEditorActionListener((v, actionId, event) -> {
                    drawingView.setDisplayText(textInput.getText().toString());
                    drawingView.invalidate();
                    return true;
                });
// Handle clear button
                btnClear.setOnClickListener(v -> drawingView.clearCanvas());
            }
        }
